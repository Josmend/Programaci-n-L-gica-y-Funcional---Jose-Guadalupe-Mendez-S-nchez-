module Main where

import Test.Tasty
import Test.Tasty.HUnit

-- Función para verificar si un número es primo
esPrimo :: Int -> Bool
esPrimo n
  | n <= 1 = False
  | otherwise = not $ any (\x -> n `mod` x == 0) [2..(n - 1)]

-- Función para convertir un número a su representación en español
numToSpanish :: Int -> String
numToSpanish 1 = "uno"
numToSpanish 2 = "dos"
numToSpanish 3 = "tres"
numToSpanish 4 = "cuatro"
numToSpanish 5 = "cinco"
numToSpanish _ = "FizzBuzz"

-- Función fizzbuzz que devuelve "FizzBuzz" si el número es primo y el número en español si no lo es
fizzbuzz :: Int -> String
fizzbuzz n
  | n `elem` [1..5] || n `elem` [16..29] = if esPrimo n then "FizzBuzz" else numToSpanish n
  | n `elem` [31..100] = if esPrimo n then "FizzBuzz" else numToSpanish n
  | n `elem` [101..999] = if esPrimo n then "FizzBuzz" else numToSpanish n
  | n `elem` [1000..999999] = if esPrimo n then "FizzBuzz" else numToSpanish n
  | otherwise = error "Número fuera del rango esperado"


grupo1Tests :: TestTree
grupo1Tests = testGroup "Pruebas para distintos rangos de números"
    [ testCase "1 is uno" $ fizzbuzz 1 @?= "uno"
    , testCase "2 is dos" $ fizzbuzz 2 @?= "FizzBuzz"
    , testCase "3 is tres" $ fizzbuzz 3 @?= "FizzBuzz"
    , testCase "4 is cuatro" $ fizzbuzz 4 @?= "cuatro"
    , testCase "5 is cinco" $ fizzbuzz 5 @?= "FizzBuzz"
    , testCase "16 is dieciséis" $ fizzbuzz 16 @?= "dieciséis"
    , testCase "17 is diecisiete" $ fizzbuzz 17 @?= "FizzBuzz"
    , testCase "18 is dieciocho" $ fizzbuzz 18 @?= "dieciocho"
    , testCase "19 is diecinueve" $ fizzbuzz 19 @?= "FizzBuzz"
    , testCase "20 is veinte" $ fizzbuzz 20 @?= "FizzBuzz"
    , testCase "21 is veinti uno" $ fizzbuzz 21 @?= "veinti uno"
    , testCase "22 is veintidós" $ fizzbuzz 22 @?= "veintidós"
    , testCase "23 is veintitrés" $ fizzbuzz 23 @?= "FizzBuzz"
    , testCase "24 is veinticuatro" $ fizzbuzz 24 @?= "veinticuatro"
    , testCase "25 is veinticinco" $ fizzbuzz 25 @?= "FizzBuzz"
    , testCase "26 is veintiséis" $ fizzbuzz 26 @?= "veintiséis"
    , testCase "27 is veintisiete" $ fizzbuzz 27 @?= "FizzBuzz"
    , testCase "28 is veintiocho" $ fizzbuzz 28 @?= "veintiocho"
    , testCase "29 is veintinueve" $ fizzbuzz 29 @?= "FizzBuzz"
    , testCase "31 is treinta y uno" $ fizzbuzz 31 @?= "treinta y uno"
    , testCase "40 is cuarenta" $ fizzbuzz 40 @?= "cuarenta"
    , testCase "50 is cincuenta" $ fizzbuzz 50 @?= "cincuenta"
    , testCase "60 is sesenta" $ fizzbuzz 60 @?= "sesenta"
    , testCase "70 is setenta" $ fizzbuzz 70 @?= "FizzBuzz"
    , testCase "80 is ochenta" $ fizzbuzz 80 @?= "ochenta"
    , testCase "90 is noventa" $ fizzbuzz 90 @?= "noventa"
    , testCase "100 is cien" $ fizzbuzz 100 @?= "cien"
    , testCase "101 is ciento uno" $ fizzbuzz 101 @?= "ciento uno"
    , testCase "200 is doscientos" $ fizzbuzz 200 @?= "doscientos"
    , testCase "300 is trescientos" $ fizzbuzz 300 @?= "trescientos"
    , testCase "400 is cuatrocientos" $ fizzbuzz 400 @?= "cuatrocientos"
    , testCase "500 is quinientos" $ fizzbuzz 500 @?= "quinientos"
    , testCase "600 is seiscientos" $ fizzbuzz 600 @?= "seiscientos"
    , testCase "700 is setecientos" $ fizzbuzz 700 @?= "setecientos"
    , testCase "800 is ochocientos" $ fizzbuzz 800 @?= "ochocientos"
    , testCase "900 is novecientos" $ fizzbuzz 900 @?= "novecientos"
    , testCase "999 is novecientos noventa y nueve" $ fizzbuzz 999 @?= "novecientos noventa y nueve"
    , testCase "1000 is mil" $ fizzbuzz 1000 @?= "mil"
    , testCase "1001 is mil uno" $ fizzbuzz 1001 @?= "mil uno"
    , testCase "2000 is dos mil" $ fizzbuzz 2000 @?= "dos mil"
    , testCase "5000 is cinco mil" $ fizzbuzz 5000 @?= "cinco mil"
    , testCase "10000 is diez mil" $ fizzbuzz 10000 @?= "diez mil"
    , testCase "100000 is cien mil" $ fizzbuzz 100000 @?= "cien mil"
    , testCase "999999 is novecientos noventa y nueve mil novecientos noventa y nueve" $ fizzbuzz 999999 @?= "novecientos noventa y nueve mil novecientos noventa y nueve"
    ]

-- Conjunto completo de pruebas
tests :: TestTree
tests = testGroup "Tests" [grupo1Tests]

-- Función de entrada
main :: IO ()
main = defaultMain tests
